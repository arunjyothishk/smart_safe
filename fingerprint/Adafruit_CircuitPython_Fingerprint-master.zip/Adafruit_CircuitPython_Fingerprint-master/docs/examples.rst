Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/fingerprint_simpletest.py
    :caption: examples/fingerprint_simpletest.py
    :linenos:
